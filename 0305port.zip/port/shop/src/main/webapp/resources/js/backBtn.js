
$('#back_Btn').click(function(){
//location.href="/admin/goods/view?n"+${goods.gdsNum};
   history.back();
});