package com.my.shop.vo;

import java.util.Date;

/*
 create table tbl_order(
orderId varchar2(200) not null,
userId varchar2(200) not null,
orderRec varchar2(200) not null,
userAddr1 varchar2(200) not null,
userAddr2 varchar2(200) not null,
userAddr3 varchar2(200) not null,
orderPhone varchar2(200) not null,
amount number not null,
orderDate Date default sysdate,
primary key(orderId)
);
 */
public class OrderVO {

	private String orderId, userId, orderRec, userAddr1, userAddr2, userAddr3, orderPhone;
	private int amount;
	private Date orderDate;
	
	//getter
	public String getOrderId() {return orderId;}
	public String getUserId() {return userId;}
	public String getOrderRec() {return orderRec;}
	public String getUserAddr1() {return userAddr1;}
	public String getUserAddr2() {return userAddr2;}
	public String getUserAddr3() {return userAddr3;}
	public String getOrderPhone() {return orderPhone;}
	public int getAmount() {return amount;}
	public Date getOrderDate() {return orderDate;}
	
	//setter
	public void setOrderId(String orderId) {this.orderId = orderId;}
	public void setUserId(String userId) {this.userId = userId;}
	public void setOrderRec(String orderRec) {this.orderRec = orderRec;}
	public void setUserAddr1(String userAddr1) {this.userAddr1 = userAddr1;}
	public void setUserAddr2(String userAddr2) {this.userAddr2 = userAddr2;}
	public void setUserAddr3(String userAddr3) {this.userAddr3 = userAddr3;}
	public void setOrderPhone(String orderPhone) {this.orderPhone = orderPhone;}
	public void setAmount(int amount) {this.amount = amount;}
	public void setOrderDate(Date orderDate) {this.orderDate = orderDate;}
	
}
